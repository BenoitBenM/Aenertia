follow_mode = False
HumanDetected = False
offset = 0